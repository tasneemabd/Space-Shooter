//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine.UI;
//using UnityEngine;


//public class Player : MonoBehaviour
//{
//    public GameManger GameManger;
//    public GameObject palyerBullet;
//    public GameObject bulletPosation01;
//    public GameObject bulletPosation02;
//    public GameObject ExplosionGo;

//    public Text LivesUIText;

//    public AudioClip shootSound; // Add this variable to hold the shoot sound
//    private AudioSource audioSource; // AudioSource component to play the sound


//    const int MaxLives = 3;
//    int     Lives;

//    public void Init()
//    {
//        Lives = MaxLives;
//        LivesUIText.text = Lives.ToString();


//        transform.position = new Vector2(0, 0);
//        gameObject.SetActive(true);
//    }

//    public float speed;
//    // Start is called before the first frame update
//    void Start()
//    {

//    }

//    // Update is called once per frame
//    void Update()
//    {

//        if (Input.GetKeyDown("space"))

//        {
//            if (shootSound != null && audioSource != null)
//            {
//                audioSource.PlayOneShot(shootSound);
//            }


//            GameObject bullet01 = (GameObject)Instantiate(palyerBullet);

//            bullet01.transform.position = bulletPosation01.transform.position;

//            GameObject bullet02 = (GameObject)Instantiate(palyerBullet);

//            bullet02.transform.position = bulletPosation02.transform.position;



//        }
//        float x = Input.GetAxisRaw("Horizontal"); // the value  will be  -1,0 or 1 (for left , no input , and right )
//        float y = Input.GetAxisRaw("Vertical"); // the value  will be  -1,0 or 1 (for down , no input , and up )

//        Vector2 direction = new Vector2(x, y).normalized;

//        Move(direction);

//    }



//    void FireBullet()
//    {
//        if (shootSound != null && audioSource != null)
//        {
//            audioSource.PlayOneShot(shootSound);
//        }

//        GameObject bullet01 = (GameObject)Instantiate(palyerBullet);
//        bullet01.transform.position = bulletPosation01.transform.position;

//        GameObject bullet02 = (GameObject)Instantiate(palyerBullet);
//        bullet02.transform.position = bulletPosation02.transform.position;
//    }

//    void Move(Vector2 direction)
//    {
//        Vector2 min = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));
//        Vector2 max = Camera.main.ViewportToWorldPoint(new Vector2(1, 1));

//        max.x = max.x - 0.225f;
//        min.x = min.x - 0.225f;

//        max.y = max.x - 0.285f;
//        min.y = min.x - 0.285f;
//        Vector2 pos = transform.position;
//        pos += direction * speed * Time.deltaTime;

//        pos.x = Mathf.Clamp (pos.x, min.x,max.x);

//        pos.y = Mathf.Clamp(pos.y, min.y, max.y);
//        transform.position = pos;





//    }

//    private void OnTriggerEnter2D(Collider2D collision)
//    {
//        if (collision.tag == "EnemyShipTag" || (collision.tag == "EnemyBulletTag"))
//        {
//            PlayExplosion();
//            Lives--;
//            LivesUIText.text = Lives.ToString();

//            if (Lives == 0)
//            {
//                GameManger.GetComponent<GameManger>().setGameMangerState(GameManger.GameMangerState.GameOver);
//                // Destroy(gameObject);

//                gameObject.SetActive(false);    
//            }
//        }
//    }

//    void PlayExplosion()
//    {
//        GameObject explosion = (GameObject)Instantiate(ExplosionGo);

//        explosion.transform.position = transform.position;
//    }
//}

//ـــ-----------------------------------------------------------------------------------------------------------------------------------------------------------
using UnityEngine.UI;
using UnityEngine;

public class Player : MonoBehaviour
{

    public GameManger GameManger;
    public GameObject playerBullet;
    public GameObject bulletPosition01;
    public GameObject bulletPosition02;
    public GameObject ExplosionGo;
    public HealthManager healthManager;
    public Text livesUIText;

    public AudioClip shootSound;
    private AudioSource audioSource;



    const int MaxLives = 3;
    int Lives;

    public void Init()
    {
        Lives = MaxLives;
        livesUIText.text = Lives.ToString();

        transform.position = Vector2.zero;
        gameObject.SetActive(true);
    }

    public float speed;

    void Update()
    {
        HandleMovementInput();
        HandleShootingInput();
    }

    void HandleMovementInput()
    {
        // Keyboard input
        float x = Input.GetAxisRaw("Horizontal");
        float y = Input.GetAxisRaw("Vertical");

        // Touch input
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0); // Assuming only one touch for simplicity
            Vector2 touchPosition = Camera.main.ScreenToWorldPoint(touch.position);

            // Calculate direction based on touch position relative to the player
            x = touchPosition.x - transform.position.x;
            y = touchPosition.y - transform.position.y;
        }

        Vector2 direction = new Vector2(x, y).normalized;
        Move(direction);
    }


    void HandleShootingInput()
    {
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
        {
            Shoot();
        }
    }

    void Shoot()
    {
        if (shootSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(shootSound);
        }

        GameObject bullet01 = Instantiate(playerBullet, bulletPosition01.transform.position, Quaternion.identity);
        GameObject bullet02 = Instantiate(playerBullet, bulletPosition02.transform.position, Quaternion.identity);
    }

    void Move(Vector2 direction)
    {
        Vector2 min = Camera.main.ViewportToWorldPoint(Vector2.zero);
        Vector2 max = Camera.main.ViewportToWorldPoint(Vector2.one);

        max.x -= 0.225f;
        min.x -= 0.225f;
        max.y -= 0.285f;
        min.y -= 0.285f;

        Vector2 pos = transform.position;
        pos += direction * speed * Time.deltaTime;

        pos.x = Mathf.Clamp(pos.x, min.x, max.x);
        pos.y = Mathf.Clamp(pos.y, min.y, max.y);

        transform.position = pos;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.CompareTag("EnemyShipTag") || collision.CompareTag("EnemyBulletTag"))
        {
            PlayExplosion();
            HealthManager.health--; // Decrement health directly from HealthManager
            //Lives--;

            //livesUIText.text = HealthManager.health.ToString();
            //livesUIText.text = Lives.ToString();

            if (HealthManager.health == 0)
            {
                GameManger.GetComponent<GameManger>().setGameMangerState(GameManger.GameMangerState.GameOver);
                gameObject.SetActive(false);
            }
        }

    }




    void PlayExplosion()
    {
        GameObject explosion = Instantiate(ExplosionGo, transform.position, Quaternion.identity);


    }

    public void RefillHearts()
    {
        healthManager.ResetHealth();
    }

}


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Planet : MonoBehaviour
{
    public float speed;
    public bool isMoving;

    Vector2 min;
    Vector2 max;


    private void Awake()
    {
        isMoving = false;
        min = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));
        max = Camera.main.ViewportToWorldPoint(new Vector2(1, 1));

        max.y = max.y + GetComponent<SpriteRenderer>().sprite.bounds.extents.y;
        min.y = min.y - GetComponent<SpriteRenderer>().sprite.bounds.extents.y;



    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!isMoving)
            return;

        Vector2 posistion = transform.position;

        posistion = new Vector2(posistion.x, posistion.y + speed * speed * Time.deltaTime);

        transform.position = posistion;

        if(transform.position.y< min.y)
        {
            isMoving = false;
        }

        
    }
    public void ResetPosaition()
    {
        transform.position = new Vector2(Random.Range(min.x, max.x), max.y);
    }
}

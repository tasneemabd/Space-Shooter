using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManger : MonoBehaviour
{
    public GameObject playButton;
    public GameObject PlayerShip;
    public GameObject enemySpawner;

    public GameObject GameOver;
    public GameObject scoreTextUI;
    public GameObject TimeCounter;




    public enum GameMangerState
    {
            Opening,
            Gamepaly,
  
        GameOver,
    }
    GameMangerState GMState;


    // Start is called before the first frame update
    void Start()
    {
        GMState = GameMangerState.Opening;
    }

    // Update is called once per frame
    void UpdateGameManagerState()
    {
        switch(GMState)
        {
            case GameMangerState.Opening:


                GameOver.SetActive(false);
                playButton.SetActive(true);

                break;

            case GameMangerState.Gamepaly:

                scoreTextUI.GetComponent<GameScore>().Score = 0;
                    
                playButton.SetActive(false);

                PlayerShip.GetComponent<Player>().Init();

                enemySpawner.GetComponent<EnemySpawner>().ScheduleEnemySpawner();
                TimeCounter.GetComponent<TimerCounter>().StartTimerCounter();


                break;
           

            case GameMangerState.GameOver:
                TimeCounter.GetComponent<TimerCounter>().StopTimeCounter();
                enemySpawner.GetComponent<EnemySpawner>().UnscheduleEnemySpawner();

                GameOver.SetActive(true);


                Invoke("changeToPoeningState", 8f);


                break;

        }
    }
    public void setGameMangerState(GameMangerState state)
    {
        GMState = state;
        UpdateGameManagerState();
    }

    public void StartGamePlay()
    {
        GMState = GameMangerState.Gamepaly;
        UpdateGameManagerState();
    }
    
 


    public void changeToPoeningState()
    {
        setGameMangerState(GameMangerState.Opening);
        PlayerShip.GetComponent<Player>().RefillHearts(); // Call the method to refill hearts
    
    }
}

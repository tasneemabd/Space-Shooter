using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject EnemyGo;


    float maxSpawnerRateInSeconds = 5f;

    // Start is called before the first frame update
    void Start()
    {
      
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void SpawnEnemy()
    {
        Vector2 min = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));
        Vector2 max = Camera.main.ViewportToWorldPoint(new Vector2(1, 1));

        // Define the number of enemies to spawn in a group
        int numberOfEnemiesInGroup = 3;

        // Loop to spawn multiple enemies in a group
        for (int i = 0; i < numberOfEnemiesInGroup; i++)
        {
            GameObject anEnemy = (GameObject)Instantiate(EnemyGo);
            // Calculate random position within the screen bounds
            float randomX = Random.Range(min.x, max.x);
            float randomY = max.y + (i * 2); // Increase Y position for each enemy in the group
            anEnemy.transform.position = new Vector2(randomX, randomY);
        }

        ScheduleNextEnemySpawn();
    }


    void ScheduleNextEnemySpawn()
    {
        float spawnInNSecands;
         if (maxSpawnerRateInSeconds > 1f)
        {
            spawnInNSecands = Random.Range(1f, maxSpawnerRateInSeconds);
        }
        else
        
            spawnInNSecands = 1f;
            Invoke("SpawnEnemy", spawnInNSecands);  
        }

         void IncreaseSpawnRate()
        {
            if (maxSpawnerRateInSeconds > 1f)
                maxSpawnerRateInSeconds--;
            if(maxSpawnerRateInSeconds ==  1f)
                    CancelInvoke("IncreaseSpawnRate");

        }

    public void ScheduleEnemySpawner()
    {
        maxSpawnerRateInSeconds = 5f;
        Invoke("SpawnEnemy", maxSpawnerRateInSeconds);

        InvokeRepeating("IncreaseSpawnRate", 0f, 30f);


    }

    public void UnscheduleEnemySpawner()
    {
        CancelInvoke("SpawnEnemy");
        CancelInvoke("IncreaseSpawnRate");
    

    }


}

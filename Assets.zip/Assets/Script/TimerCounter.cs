using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class TimerCounter : MonoBehaviour
{
    Text  TimeUi;

    float startTime;
    float elapsedTime;
    bool StartCounter;

    int minutes;
    int seconds;

    // Start is called before the first frame update
    void Start()
    {
        StartCounter = false;

        TimeUi = GetComponent<Text>();

    }
    public void StartTimerCounter()
    {
        startTime = Time.time;
        StartCounter = true;

    }

    public void StopTimeCounter()
    {
        StartCounter = false;
    }
    // Update is called once per frame
    void Update()
    {
        if (StartCounter)
        {
            elapsedTime = Time.time - startTime;
            minutes = (int)elapsedTime / 60;

            seconds = (int)elapsedTime % 60;

            TimeUi.text = string.Format("{0:00}:{1:00}", minutes, seconds);
        }
        
    }
}

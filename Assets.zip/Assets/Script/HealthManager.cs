using UnityEngine;
using UnityEngine.UI;

public class HealthManager : MonoBehaviour
{
    public static int health = 3;
    public Image[] hearts;
    public Sprite fullHeart;
    public Sprite emptyHeart;

    void Awake()
    {
        health = 3;
    }

    // Update is called once per frame
    void Update()
    {
        UpdateHeartsUI();
    }

    void UpdateHeartsUI()
    {
        for (int i = 1; i < hearts.Length; i++)
        {
            if (i < health)
                hearts[i].sprite = fullHeart;
            else
                hearts[i].sprite = emptyHeart;
        }
    }

    public void ResetHealth()
    {
        health = 3;
        UpdateHeartsUI();
    }
}
